from setuptools import setup, find_packages

setup(
    name = "MLEngineer_Practica1",
    version = "0.1",
    license = "MIT",
    description = "Paquete de proyecto Practica 1",
    author= "Alexander Paucar y Stephen Morales",
    packages = find_packages(),
    url = "https://github.com/alexgor10/MLE_Entregable1.git"
)